#!/sbin/sh
# 
# /system/addon.d/90-audiohal.sh
# During a ROM upgrade, this script backs up old AudioHAL files,
# /system is formatted and reinstalled, then the files is restored.
# Author: DodoGTA@XDA
#

. /tmp/backuptool.functions

list_files() {
cat <<EOF
etc/asound.conf
lib/lib_DNSe_NRSS_ver224c.so
lib/lib_Samsung_Resampler.so
lib/lib_SamsungRec_V01006.so
lib/libsamsungRecord.so
lib/libsamsungRecord_ns.so
lib/libsamsungSoundbooster.so
lib/hw/audio.primary.hawaii.so
usr/lib/alsa-lib/libasound_module_pcm_bcmfilter.so
usr/lib/alsa-lib/libbcm_hp_filter.so
usr/lib/alsa-lib/libbcm_test_filter.so
usr/share/alsa/alsa.conf
EOF
}

case "$1" in
  backup)
    list_files | while read FILE DUMMY; do
      backup_file $S/"$FILE"
    done
  ;;
  restore)
    list_files | while read FILE REPLACEMENT; do
      R=""
      [ -n "$REPLACEMENT" ] && R="$S/$REPLACEMENT"
      [ -f "$C/$S/$FILE" ] && restore_file $S/"$FILE" "$R"
    done
  ;;
  pre-backup)
    # Stub
  ;;
  post-backup)
    # Stub
  ;;
  pre-restore)
    # Stub
  ;;
  post-restore)
rm -rf /system/lib/lib_SamsungRec_V03011b.so
rm -rf /system/lib/libbcm_hp_filter.so
rm -rf /system/lib/libtinyalsa_ext.so
  ;;
esac
